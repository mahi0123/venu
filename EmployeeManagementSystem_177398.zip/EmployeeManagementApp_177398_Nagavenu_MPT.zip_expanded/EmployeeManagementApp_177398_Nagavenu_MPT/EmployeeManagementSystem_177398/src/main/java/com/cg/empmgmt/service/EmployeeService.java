package com.cg.empmgmt.service;

import java.util.List;

import com.cg.empmgmt.entities.Employee;

public interface EmployeeService {

	void create (Employee emp);
	void update (Employee emp);
	void delete (String empid);
	List<Employee>listofemployees();
	Employee SearchEmployee(String empid);
	
}
