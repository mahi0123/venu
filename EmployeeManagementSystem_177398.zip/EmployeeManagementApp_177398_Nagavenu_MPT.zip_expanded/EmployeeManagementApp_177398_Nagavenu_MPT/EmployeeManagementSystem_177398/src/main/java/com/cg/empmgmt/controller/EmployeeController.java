package com.cg.empmgmt.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.empmgmt.entities.Employee;
import com.cg.empmgmt.service.EmployeeService;

@RestController
@RequestMapping("")
public class EmployeeController {

	@Autowired
	private EmployeeService empservice;
	
	//Creating Employee 
	//TestURL: http://localhost:8080/create
	@PostMapping(value= {"/create"}, consumes= {"application/json","application/xml"})
	
	public ResponseEntity<String> create(@RequestBody Employee emp)
	{

		System.out.print("Creating Employee..."+emp.getEmpid());
		
		empservice.create(emp);
		return new ResponseEntity<String>("Employee Created ",HttpStatus.CREATED);
				
	}
	
	
		
	//TestURL: http://localhost:8080/updateemployee
	
	@PutMapping(value= {"/updateemployee"}, consumes= {"application/json","application/xml"})
	public ResponseEntity<String> update(@RequestBody Employee emp)
	{
		System.out.print("Updating Employee Information..."+emp.getEmpid());
		empservice.update(emp);
		return new ResponseEntity<String>("Employee Information Updated \n"+emp.toString(),HttpStatus.OK);
		
	}
	
	//TestURL: http://localhost:8080/delete/1001
	
	@DeleteMapping(value= {"/delete/{empid}"})
	
	public ResponseEntity<String> delete(@PathVariable String empid)
	{
		empservice.delete(empid);
		
		return new ResponseEntity<String>("Employee information deleted",HttpStatus.OK);
		
	}
	
	
	//TestURL: http://localhost:8080/employees
	@GetMapping(value= {"/employees"})
	public List<Employee> listofemployees()
	{
		return empservice.listofemployees();
		
	}
	
	
	//TestURL: http://localhost:8080/getbyid?empid=1001
	
	@GetMapping(value= {"/getbyid"})
	public Employee search(@RequestParam("empid") String empid)
	{
		
		System.out.println("Retriving Account"+empid);
		
		return empservice.SearchEmployee(empid);
		
	}
	
	
	
	
	
}
