package com.cg.empmgmt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmployeeManagementSystem177398Application {

	public static void main(String[] args) {
		SpringApplication.run(EmployeeManagementSystem177398Application.class, args);
	}

}
