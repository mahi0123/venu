package com.cg.empmgmt.service;

import static org.hamcrest.CoreMatchers.nullValue;

import java.util.LinkedList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.empmgmt.dao.EmployeeDao;
import com.cg.empmgmt.entities.Employee;
import com.cg.empmgmt.exceptions.ApplicationException;

@Service
public class EmployeeserviceImpl implements EmployeeService {

	
	@Autowired
	
	private EmployeeDao empdao;
	
	
	//Creating Employee  
	@Transactional
	public void create(Employee emp) {
		
		empdao.save(emp);
	}

	
	//Updating Employee Information
	@Transactional
	public void update(Employee emp) {
		
		
		
		empdao.save(emp);
	}

	
	//removing the Employee usind empid
	@Transactional
	public void delete(String empid) {
		Optional<Employee> e =empdao.findById(empid);
		if(!e.isPresent())
		{
			throw new ApplicationException("Employee not exist to delete..!");
		}
		
		empdao.deleteById(empid);
		
		
	}
	
	//Displaying list of employees

	@Transactional
	public List<Employee> listofemployees() {
		
		List<Employee>emplist=empdao.findAll();
		if(emplist.isEmpty())
		{
			throw new ApplicationException("No Employees available and list is empty");
		}
		
		return empdao.findAll();
	}

	
	//Retrieving Employee Information using empid
	@Transactional
	public Employee SearchEmployee(String empid) {
		
		Optional<Employee> e =empdao.findById(empid);
		if(!e.isPresent())
		{
			throw new ApplicationException("Employee not found..!");
		}
		
		
		return e.get();
	}

	
	
	
}
