import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
import { AddComponent } from './add/add.component';
import { EditUserComponent } from './edit-user/edit-user.component';
import { ListUserComponent } from './list-user/list-user.component';
import { HttpClient, HttpClientModule } from '../../node_modules/@angular/common/http';
import {ReactiveFormsModule,FormsModule} from '@angular/forms';
import { NamePipe } from './pipes/name.pipe';


@NgModule({
  //all user defined componenets,directives,pipes
  declarations: [
    AppComponent,
    HomeComponent,
    LoginComponent,
    AddComponent,
    EditUserComponent,
    ListUserComponent,
    NamePipe,
    
    
  ],
  //all user defined and predefined modules
  imports: [
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule
  ],
  //all user defined services
  providers: [],
  //kick startting the application[Root component name]
  bootstrap: [AppComponent]
})
export class AppModule { }
