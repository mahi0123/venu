import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '../../../node_modules/@angular/forms';
import { Router, ActivatedRoute } from '../../../node_modules/@angular/router';
import { UserService } from '../services/user.service';
import { User } from '../model/user.model';

@Component({
  selector: 'app-edit-user',
  templateUrl: './edit-user.component.html',
  styleUrls: ['./edit-user.component.css']
})
export class EditUserComponent implements OnInit {
  
  editForm: FormGroup;

  submitted: boolean=false;
  user:User;
  userId:string
  constructor(private formBuilder:FormBuilder , private router: Router,
    private route:ActivatedRoute,private userService:UserService) { }
 //LogoffUser
 logoutUser(){
   if(localStorage.getItem("username")!=null){
     localStorage.removeItem("username");
     this.router.navigate(['/login']);
   }
 }

  ngOnInit() {
    // if(localStorage.getItem("username")!=null)
    // {
    //   let userId=localStorage.getItem("editUserId");
    if(this.userId!=null)
    {
      if(!this.userId)
      {
        alert('Invalid Action');
        this.router.navigate(['list-user']);
        return;
      }
    
    this.editForm=this.formBuilder.group({
      id:[],
      firstName:['',Validators.required],
      lastName:['',Validators.required],
      email:['' ,Validators.required ]
    });
    //pulling data from database using service
    // this.userService.getUserbyId(+userId).subscribe
    // (data=>{this.editForm.setValue(data)});
    this.userService.getUserbyId(+this.userId).subscribe
    (data=>{this.editForm.setValue(data)});
  }
  else{
    this.router.navigate(['/login'])
  }
  
   }
   //OnSubmit function

   onSubmit(){
    this.submitted=true;
    if(this.editForm.invalid)
    {
      return;
    }
    console.log(this.editForm.value);
    this.userService.updateUser(this.editForm.value)
    .subscribe(data=>{alert(this.editForm.controls.firstName.value+'record is added successfully');
   this.router.navigate(['list-user']);
  },error=>{
    alert(error);
  });
  }
  

}
