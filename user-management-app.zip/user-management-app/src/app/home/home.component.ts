import { Component, OnInit } from '@angular/core';
import { MathService } from '../services/math.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
title:string="Welcome to Angular 6"


  result:number;
  a:number=10;
  b:number=20;
  result1:number;
  //Dependency Injection
  constructor(private mathService:MathService){}



  ngOnInit() {
    this.result=this.mathService.addition(this.a,this.b);
    console.log("Addition is "+this.result);
    this.result1=this.mathService.multiplication(this.a,this.b);
    console.log("Multiplication is "+this.result1)
  }
 
}
