import { Component, OnInit } from '@angular/core';
import { MathService } from '../services/math.service';
import { FormGroup, FormBuilder, Validators } from '../../../node_modules/@angular/forms';
import { Router } from '../../../node_modules/@angular/router';
import { UserService } from '../services/user.service';

@Component({
  selector: 'app-add',
  templateUrl: './add.component.html',
  styleUrls: ['./add.component.css']
})
export class AddComponent implements OnInit {

  addForm: FormGroup;

  submitted: boolean=false;
 

 
  constructor(private formBuilder:FormBuilder , private router: Router,private userService:UserService) { }
 

  ngOnInit() {

    this.addForm=this.formBuilder.group({
      id:[],
      firstName:['',Validators.required],
      lastName:['',Validators.required],
      email:['' ,[Validators.required,Validators.required] ]
    })
  
   }
   //OnSubmit function

   onSubmit(){
     this.submitted=true;
     if(this.addForm.invalid)
     {
       return;
     }
     console.log(this.addForm.value);
     this.userService.createUser(this.addForm.value)
     .subscribe(data=>{alert(this.addForm.controls.firstName.value+'record is added successfully');
    this.router.navigate(['list-user']);})
   }

}
