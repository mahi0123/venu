import { Component, OnInit } from '@angular/core';

import { FormBuilder, FormGroup, Validators } from '../../../node_modules/@angular/forms';

import { Router } from '../../../node_modules/@angular/router';



@Component({

 selector: 'app-login',

 templateUrl: './login.component.html',

 styleUrls: ['./login.component.css']

})

export class LoginComponent implements OnInit {

 //Instance Variables -

 //Nydefault public in Typescript



 loginForm: FormGroup;

 submitted: boolean=false;

 invalidLogin: boolean=false;

 constructor(private formBuilder:FormBuilder , private router: Router) { }

 onSubmit(){

  this.submitted=true;

  //If Validation failed, it should return

  //to Validate again

  if(this.loginForm.invalid){

   return;

  }



  let username=

  this.loginForm.controls.email.value;
  let password=this.loginForm.controls.password.value;

  if(

  username== "admin@gmail.com" && password =="123456")

  {

   localStorage.setItem("username",username);

   this.router.navigate(['list-user']);

  }

  else{

   this.invalidLogin=true;

  }



 }



 ngOnInit() {

  this.loginForm=this.formBuilder.group({

   email:['' ,Validators.required],

   password:['' , Validators.required ]

  })

 }



}

