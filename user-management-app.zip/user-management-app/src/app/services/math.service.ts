import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class MathService {

  constructor() { }

  //addition
  addition(fn:number,sn:number){
    return fn+sn;
  }
  //multiplication
  multiplication(fn:number,sn:number){
    return fn*sn;
  }
}
