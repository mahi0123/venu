import { Component } from '@angular/core';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  // template:`<h1>Welcome to My app..!</h1>
  // <hr/>
  // <h2>This is Root component/>`,
  styleUrls: ['./app.component.css']
  
})
export class AppComponent {
  title = 'A2Z Solutions';
  developer='Nagavenu';
  todaysdate=new Date();


  //json data
  cust={
    name:'Nagavenu',
    age:22,
    address:{
      city:'chennai',
      state:'TamilNadu'
    }
  }



}
